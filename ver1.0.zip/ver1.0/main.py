import tkinter as tk
from tkinter import filedialog
import os
import json
import csv
from PIL import Image, ImageDraw ,ImageFont
import tkinter.messagebox as mb
root=tk.Tk()
root.geometry("800x640")
root.title("Database")
root2=tk.Tk()
root2.geometry("300x640")
root2.title("List")
root.resizable(False, False)
root2.resizable(False, False)
root.geometry("+350+50")
root2.geometry("+50+50")
def oc():
  root.destroy()
  root2.destroy()
root.protocol("WM_DELETE_WINDOW", oc)
root2.protocol("WM_DELETE_WINDOW", oc)
decklist=[]

def update_scene():
    #画面の初期化
    for widget in root.winfo_children():
        widget.destroy()
def update_scene2():
    #画面の初期化
    for widget in root2.winfo_children():
        widget.destroy()
    button= tk.Button(root2,text=f"出力",font=("Arial",12),command=lambda:cardprint(decklist))
    button.place(x=250,y=610)
update_scene2()
    

def load():
 filename=""
 jsons=[]
 jsons2=[]
 for filename in sorted(os.listdir("data")):
    if filename.endswith('.json'):
        file_path = os.path.join("data", filename)
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            jsons.append(data)
            jsons2.append(filename)
 return(jsons)

def nameload():
 r=[]
 with open('data/exp.csv', newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    for expname in reader:
        r.append(expname) 
 return(r)
    
#setnumはjsonファイルの番号
def shosai(setnum,a):
   update_scene()
   naming=""
   c=load()[setnum][a]
   naming=c['title']
   cost=c['cost']
   attack=c['atk']
   defence=c['def']
   skill=c['skill']
   if skill == "":
      skill = "効果なし"
   title = tk.Label(root,text=f"{cost}:{naming}",font=("Arial",20))
   title.place(x=100,y=100)
   title = tk.Label(root,text=f"atk: {attack} ,def: {defence} ",font=("Arial",20))
   title.place(x=100,y=150)
   title = tk.Label(root,text=f"{skill}",font=("Arial",20),wraplength=670)
   title.place(x=100,y=250)
   button= tk.Button(root,text=f"戻る",font=("Arial",20),command=lambda:cardlist(setnum))
   button.place(x=10,y=520)
   button= tk.Button(root,text=f"追加",font=("Arial",20),command=lambda:tuika(setnum,a,1))
   button.place(x=100,y=520)
def sakuzyo(n):
   global decklist
   decklist.pop(n)
   tuika(0,0,0)

def tuika(setnum,i,mode):
  global decklist
  update_scene2()

  if mode != 0:
   if len(decklist) < 32:
    decklist.append(load()[setnum][i])
   else:
    mb.askokcancel('枚数オーバーです')
  for i in range(len(decklist)):
    title = tk.Label(root2,text=f"{decklist[i]['title']}",font=("Arial",10))
    title.place(x=50,y=i*20)
    button = tk.Button(root2,text="削除",font=("Arial",7),command=lambda i=i:sakuzyo(i))
    button.place(x=10,y=i*20)
    title=tk.Label(root2,text=f"枚数:{len(decklist)}",font=("Arial",10))
    title.place(x=250,y=580)


def cardlist(setnum):
  update_scene()
  #cards変数に、load関数で読み込んだカード情報を入れる。
  cards=load()[setnum]
  listing=[]
  costing=[]
  atking=[]
  defing=[]
  #listing変数に、カード情報の"title"を抜き出したものを入れる。以下略
  for i in (range(len(cards))):
   listing.append(cards[i]['title'])
   costing.append(cards[i]['cost'])
   atking.append(cards[i]['atk'])
   defing.append(cards[i]['def'])
  b=0
  for i in range(len(listing)):
     if i == 16:
        b=1
     if i == 32:
        b=2
     title = tk.Label(root,text=f"{costing[i]} : {listing[i]} {atking[i]},{defing[i]}",font=("Arial",16))
     title.place(x=90+b*400,y=10+25*i-25*b*i)
     button= tk.Button(root,text=f"効果",font=("Arial",8),command=lambda i=i:shosai(setnum,i))
     button.place(x=50+b*400,y=10+25*i-25*b*i)
     button= tk.Button(root,text=f"追加",font=("Arial",8),command=lambda i=i:tuika(setnum,i,1))
     button.place(x=10+b*400,y=10+25*i-25*b*i)
  button= tk.Button(root,text=f"戻る",font=("Arial",20),command=lambda:main(1,0))
  button.place(x=10,y=520)

def cardprint(dl):
 w = 3508
 h = 2480
 img =Image.new("RGB",(w,h),"white")
 draw = ImageDraw.Draw(img)
 font = ImageFont.truetype("meiryo.ttc", 48)
 y=0
 x=0 

 for i in range(len(dl)):
    draw.rectangle(
    [1+x*438.5, 1+y*620, x*438.5 + 438.5 - 1, y*620 + 620 - 1],outline=(200, 200, 200),width=1)
    draw.text((15+x*438.5,y*620),str(dl[i]['cost']),fill="black",font=font)
    a=len(dl[i]['title'])
    font2 = ImageFont.truetype("meiryo.ttc", 60-a*3)
    draw.text((x*438.5+65,y*620+a),str(dl[i]['title']),fill="black",font=font2)
    draw.text((15+x*438.5,y*620+550),f"at:{str(dl[i]['atk'])}",fill="red",font=font)
    draw.text((x*438.5+270,y*620+550),f"df:{str(dl[i]['def'])}",fill="blue",font=font)
#ここに、forループで13文字ずつ切り取って配置する処理を入れる
    font3 = ImageFont.truetype("meiryo.ttc", 30)
    font4 = ImageFont.truetype("meiryo.ttc", 25)
    c=str(dl[i]['skill'])
    if len(c) > 13:
      i3=0
      for i2 in range(len(c)):
       print(c[i2])
       if i3 == 0:
        draw.text((5+x*438.5,y*620+270+i2*2),c[i2:i2+17],fill="black",font=font4)  
       if i3 == 16:
        i3=-1
       i3+=1   
    else:
      draw.text((5+x*438.5,y*620+270),c,fill="black",font=font3)    
    x+=1
    if x==8:
     y+=1
     x=0
 if len(decklist) < 1:
  mb.showwarning("エラー","カードが1枚もありません！")
 else:
  fp=filedialog.asksaveasfilename(defaultextension=".png",
        filetypes=[("PNG files", "*.png")],
        initialfile="cardlist.png",
        title="画像を保存")
  img.save(fp, dpi=(300, 300))
  mb.showinfo("完了","ファイルを保存しました！")
def main(a,num):
   global cardlist
   update_scene()
   if a == 1:
      def draw():
       c=nameload()
       b=0
       #パック情報を表示
       for i in range(len(load())):
          if i == 16:
             b=1
          if i == 32:
             b=2
          title = tk.Label(root,text=f"{c[i][1]}",font=("Arial",16))
          title.place(x=50+b*200,y=10+25*i)
          button= tk.Button(root,text=f"set{i}",font=("Arial",8),command=lambda i=i:main(2,i))
          button.place(x=10+b*200,y=10+25*i)

       
      draw()
   if a == 2:
      cardlist(num)


   
cardlist(0)
main(1,0)

root.mainloop()